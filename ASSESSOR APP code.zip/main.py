import os
import sys
import kivy
kivy.require('2.0.0')

from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.image import Image as KivyImage
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout
from kivy.clock import Clock, mainthread
from kivy.core.window import Window
from kivy.metrics import sp, dp
from kivy.uix.widget import Widget
from kivy.uix.popup import Popup
from kivy.graphics import Color, RoundedRectangle, Rectangle, Line
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.anchorlayout import AnchorLayout
from threading import Thread
import queue
import gc
import numpy as np
import json
from PIL import Image, ImageDraw, ImageFont
import datetime
import cv2
import pandas as pd

from kivy.utils import platform
if platform == "android":
    from jnius import autoclass, cast
    from android.permissions import request_permissions, Permission
    from android.storage import primary_external_storage_path
    from android import activity

# Global caches for performance
_font_cache = {}
_location_cache = {'last_location': None, 'timestamp': 0}
_image_cache = {}


def get_cached_font(size, bold=False):
    """Get cached font or create and cache new one"""
    cache_key = (size, bold)
    if cache_key in _font_cache:
        return _font_cache[cache_key]
    
    font_paths_to_try = [
        "/system/fonts/DroidSans-Bold.ttf" if bold else "/system/fonts/DroidSans.ttf",
        "/system/fonts/Roboto-Bold.ttf" if bold else "/system/fonts/Roboto-Regular.ttf",
        "arial.ttf",
        "Arial.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/System/Library/Fonts/Arial.ttf",
    ]
    
    for font_path in font_paths_to_try:
        try:
            font = ImageFont.truetype(font_path, size)
            _font_cache[cache_key] = font
            return font
        except (IOError, OSError):
            continue
    
    # Fallback to default font
    font = ImageFont.load_default()
    _font_cache[cache_key] = font
    return font

def get_text_size_fast(text, font):
    """Fast text size calculation with caching"""
    try:
        if hasattr(font, 'getsize'):
            return font.getsize(text)
        elif hasattr(font, 'getbbox'):
            bbox = font.getbbox(text)
            return bbox[2] - bbox[0], bbox[3] - bbox[1]
        else:
            # Fallback estimation
            char_width = getattr(font, 'size', 11) * 0.6 if hasattr(font, 'size') else 7
            char_height = getattr(font, 'size', 11) if hasattr(font, 'size') else 11
            return int(len(text) * char_width), int(char_height)
    except:
        return int(len(text) * 7), 11

def resize_image_fast(image, max_width, max_height):
    """Fast image resizing with caching"""
    if image.width <= max_width and image.height <= max_height:
        return image
    
    ratio = min(max_width / image.width, max_height / image.height)
    new_width = int(image.width * ratio)
    new_height = int(image.height * ratio)
    
    # Use faster resampling for Android
    resample = Image.LANCZOS if not ANDROID else Image.BILINEAR
    return image.resize((new_width, new_height), resample)

def ciede2000(Lab_1, Lab_2):
    import math
    L1, a1, b1 = Lab_1
    L2, a2, b2 = Lab_2

    C1 = math.hypot(a1, b1)
    C2 = math.hypot(a2, b2)
    avg_C = (C1 + C2) / 2.0

    G = 0.5 * (1 - math.sqrt((avg_C ** 7) / (avg_C ** 7 + 25 ** 7)))
    a1p = (1 + G) * a1
    a2p = (1 + G) * a2
    C1p = math.hypot(a1p, b1)
    C2p = math.hypot(a2p, b2)
    avg_Cp = (C1p + C2p) / 2.0

    h1p = math.degrees(math.atan2(b1, a1p)) % 360
    h2p = math.degrees(math.atan2(b2, a2p)) % 360

    dhp = h2p - h1p
    if dhp > 180:
        dhp -= 360
    elif dhp < -180:
        dhp += 360

    dLp = L2 - L1
    dCp = C2p - C1p
    dhp_rad = math.radians(dhp)
    if C1p * C2p == 0:
        dHp = 0
    else:
        dHp = 2 * math.sqrt(C1p * C2p) * math.sin(dhp_rad / 2.0)

    avg_Lp = (L1 + L2) / 2.0
    avg_Cp = (C1p + C2p) / 2.0

    if C1p * C2p == 0:
        avg_hp = h1p + h2p
    else:
        if abs(h1p - h2p) > 180:
            avg_hp = (h1p + h2p + 360) / 2.0
        else:
            avg_hp = (h1p + h2p) / 2.0

    T = (1
         - 0.17 * math.cos(math.radians(avg_hp - 30))
         + 0.24 * math.cos(math.radians(2 * avg_hp))
         + 0.32 * math.cos(math.radians(3 * avg_hp + 6))
         - 0.20 * math.cos(math.radians(4 * avg_hp - 63)))

    d_ro = 30 * math.exp(-((avg_hp - 275) / 25) ** 2)
    Rc = 2 * math.sqrt((avg_Cp ** 7) / (avg_Cp ** 7 + 25 ** 7))
    Sl = 1 + ((0.015 * ((avg_Lp - 50) ** 2)) / math.sqrt(20 + ((avg_Lp - 50) ** 2)))
    Sc = 1 + 0.045 * avg_Cp
    Sh = 1 + 0.015 * avg_Cp * T
    Rt = -math.sin(2 * math.radians(d_ro)) * Rc

    dE = math.sqrt(
        (dLp / Sl) ** 2 +
        (dCp / Sc) ** 2 +
        (dHp / Sh) ** 2 +
        Rt * (dCp / Sc) * (dHp / Sh)
    )
    return dE

def rgb_to_lab_cv(rgb):
    """Convert RGB to LAB using OpenCV (replacement for scikit-image)"""
    # OpenCV expects BGR format and uint8
    pixel = np.array([[list(rgb)]], dtype=np.uint8)
    lab = cv2.cvtColor(pixel, cv2.COLOR_RGB2LAB)
    # Convert to float format similar to scikit-image
    lab_float = lab[0][0].astype(np.float64)
    # Normalize L to 0-100 range and a,b to -128 to 127 range (similar to scikit-image)
    lab_float[0] = lab_float[0] * 100.0 / 255.0  # L component
    lab_float[1] = lab_float[1] - 128.0  # a component
    lab_float[2] = lab_float[2] - 128.0  # b component
    return lab_float

try:
    from android.permissions import Permission, request_permissions
    from android.storage import primary_external_storage_path
    from plyer import filechooser as plyer_filechooser
    ANDROID = True
except ImportError:
    ANDROID = False
    plyer_filechooser = None

try:
    from plyer import location as plyer_location
except ImportError:
    plyer_location = None

Window.clearcolor = (1, 1, 1, 0.85)


# --- Popup Color Theme (single location for all popup color changes) ---
POPUP_THEME = {
    'bg': (1, 1, 1, 1),           # Background: white, fully opaque
    'fg': (0, 0, 0, 1),           # Foreground (text/icons): black
    'card_bg': (1, 1, 1, 1),      # Card background: white
    'card_border': (1, 1, 1, 1),  # Card border: white (invisible, or change to (0,0,0,1) for black border)
    'divider': (1, 1, 1, 1),      # Divider color: white (invisible, or change to (0,0,0,1) for black divider)
    'radius': dp(20),             # Popup/card border radius
    'button_bg': (0.2, 0.6, 1, 1),  # Button background: blue
    'button_text': (1, 1, 1, 1),    # Button text: white
}

# For backward compatibility, assign old names to theme values
POPUP_BG = POPUP_THEME['bg']
POPUP_FG = POPUP_THEME['fg']
CARD_BG = POPUP_THEME['card_bg']
CARD_BORDER = POPUP_THEME['card_border']
DIVIDER_COLOR = POPUP_THEME['divider']
ROUNDED_RADIUS = POPUP_THEME['radius']
BUTTON_COLOR = POPUP_THEME['button_bg']
BUTTON_TEXT_COLOR = POPUP_THEME['button_text']

# Consistent icon sizes throughout the app
ICON_SIZE_SMALL = dp(32)   # For header/navigation icons
ICON_SIZE_LARGE = dp(64)   # For main action buttons/camera/gallery icons

def get_android_location():
    """
    Optimized location retrieval with caching.
    Returns cached location if less than 5 minutes old, otherwise gets new location fast.
    """
    import time
    current_time = time.time()
    
    # Return cached location if it's less than 5 minutes old
    if (_location_cache['last_location'] and 
        current_time - _location_cache['timestamp'] < 300):  # 5 minutes
        return _location_cache['last_location']
    
    try:
        from jnius import autoclass, PythonJavaClass, java_method
        from android.permissions import check_permission, Permission

        if not check_permission(Permission.ACCESS_FINE_LOCATION):
            print("Location permission not granted")
            return None

        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        LocationManager = autoclass('android.location.LocationManager')
        context = PythonActivity.mActivity
        location_manager = context.getSystemService(context.LOCATION_SERVICE)

        # Try last known location first (fastest option)
        providers = [LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER]
        for provider in providers:
            try:
                last_location = location_manager.getLastKnownLocation(provider)
                if last_location:
                    location = {
                        'latitude': last_location.getLatitude(),
                        'longitude': last_location.getLongitude()
                    }
                    # Cache the location
                    _location_cache['last_location'] = location
                    _location_cache['timestamp'] = current_time
                    return location
            except Exception as e:
                print(f"Error getting last known location from {provider}: {e}")

        # If no last known location, return None quickly instead of waiting
        return None

    except Exception as e:
        print(f"JNI Android location error: {e}")
        return None
    
def get_windows_location():
    try:
        import subprocess
        ps_script = r'''
        Add-Type -AssemblyName System.Device
        $geo = New-Object System.Device.Location.GeoCoordinateWatcher
        $geo.Start()
        while (($geo.Status -ne "Ready") -and ($geo.Permission -ne "Denied")) { Start-Sleep -Milliseconds 100 }
        if ($geo.Position.Location.IsUnknown -eq $false) {
            $lat = $geo.Position.Location.Latitude
            $lon = $geo.Position.Location.Longitude
            Write-Output "$lat,$lon"
        } else {
            Write-Output "unknown"
        }
        '''
        completed = subprocess.run(
            ["powershell", "-Command", ps_script], capture_output=True, text=True, timeout=10
        )
        if completed.returncode == 0:
            loc_line = completed.stdout.strip().splitlines()[-1]
            if loc_line != "unknown" and ',' in loc_line:
                lat, lon = map(float, loc_line.split(","))
                return lat, lon
    except Exception as e:
        pass
    return None, None

class SkyBluePopup(Popup):
    def __init__(self, **kwargs):
        kwargs.setdefault('background', '')
        kwargs.setdefault('background_color', POPUP_BG)
        kwargs.setdefault('size_hint', (0.95, 0.95))
        kwargs.setdefault('auto_dismiss', False)
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(*POPUP_BG)
            self.bg_rect = RoundedRectangle(radius=[ROUNDED_RADIUS], pos=self.pos, size=self.size)
        self.bind(pos=self._update_canvas, size=self._update_canvas)
    def _update_canvas(self, *args):
        self.bg_rect.pos = self.pos
        self.bg_rect.size = self.size

class Divider(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint_y = None
        self.height = dp(1)
        with self.canvas:
            from kivy.graphics import Color, Rectangle
            Color(*DIVIDER_COLOR)
            self.rect = Rectangle(pos=self.pos, size=(Window.width, 1))
        self.bind(pos=self.update_rect, size=self.update_rect)
    def update_rect(self, *args):
        self.rect.pos = self.pos
        self.rect.size = (self.width, 1)

class CardRow(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.size_hint_y = None
        self.height = dp(60)
        self.padding = (dp(12), dp(6))
        self.spacing = dp(10)
        with self.canvas.before:
            Color(*CARD_BG)
            self.bg_rect = RoundedRectangle(
                radius=[ROUNDED_RADIUS],
                pos=self.pos,
                size=self.size
            )
            Color(*CARD_BORDER)
            self.border_rect = RoundedRectangle(
                radius=[ROUNDED_RADIUS],
                pos=self.pos,
                size=self.size,
                width=dp(2)
            )
        self.bind(pos=self.update_rect, size=self.update_rect)
    def update_rect(self, *args):
        self.bg_rect.pos = self.pos
        self.bg_rect.size = self.size
        self.border_rect.pos = self.pos
        self.border_rect.size = self.size

class SimpleScaler:
    def __init__(self, mean, scale):
        self.mean = np.array(mean)
        self.scale = np.array(scale)
    def transform(self, X):
        return (X - self.mean) / self.scale
    

class MLPModel:
    def __init__(self, weights, biases, activation='relu', classes=None):
        self.weights = [np.array(w) for w in weights]
        self.biases = [np.array(b) for b in biases]
        self.activation = activation
        self.classes = np.array(classes) if classes is not None else None

    def _relu(self, x):
        return np.maximum(0, x)

    def _softmax(self, x):
        exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
        return exp_x / np.sum(exp_x, axis=1, keepdims=True)

    def predict(self, X):
        a = X
        # Hidden layer
        z = np.dot(a, self.weights[0]) + self.biases[0]
        if self.activation == 'relu':
            a = self._relu(z)
        else:
            raise NotImplementedError("Only relu supported")
        # Output layer
        z = np.dot(a, self.weights[1]) + self.biases[1]
        probs = self._softmax(z)
        pred_idx = np.argmax(probs, axis=1)
        return self.classes[pred_idx]

class RectangularPlusButton(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ''
        self.background_down = ''
        self.background_color = (0, 0, 0, 0)  # Transparent
        
        # Use different names to avoid Kivy property conflicts
        self.bg_rect = None
        self.border_line = None  # Changed from 'border' to 'border_line'
        self.h_line = None
        self.v_line = None
        
        # Store fixed border width to prevent changes
        self.border_width = dp(1)  # Consistent border width
        
        # Schedule graphics creation after widget is ready
        Clock.schedule_once(self.create_graphics, 0.1)
        self.bind(pos=self.update_graphics, size=self.update_graphics)
    
    def create_graphics(self, dt):
        if self.canvas is None:
            return
        
        # Clear any existing graphics first
        self.canvas.before.clear()
            
        with self.canvas.before:
            # White background
            Color(1, 1, 1, 1)
            self.bg_rect = Rectangle(pos=self.pos, size=self.size)
            
            # Black border with consistent width
            Color(0, 0, 0, 1)
            self.border_line = Line(width=self.border_width)
            
            # Black plus sign
            Color(0, 0, 0, 1)
            self.h_line = Line(width=dp(2))
            self.v_line = Line(width=dp(2))
        
        self.update_graphics()
    
    def update_graphics(self, *args):
        if not all([self.bg_rect, self.border_line, self.h_line, self.v_line]):
            return
            
        try:
            # Update background rectangle
            self.bg_rect.pos = self.pos
            self.bg_rect.size = self.size
            
            # Update border with consistent width
            self.border_line.width = self.border_width  # Ensure width stays consistent
            self.border_line.rectangle = (self.x, self.y, self.width, self.height)
            
            # Calculate plus sign lines
            center_x = self.center_x
            center_y = self.center_y
            line_length = min(self.width, self.height) * 0.5
            
            # Update horizontal line
            self.h_line.points = [
                center_x - line_length/2, center_y,
                center_x + line_length/2, center_y
            ]
            
            # Update vertical line
            self.v_line.points = [
                center_x, center_y - line_length/2,
                center_x, center_y + line_length/2
            ]
        except Exception as e:
            print(f"Error updating graphics: {e}")


class ImageClassifier:
        """Exact implementation matching reference code logic"""
        
        def __init__(self, model, scaler, model_name=None, model_accuracy=None, use_scaled=True):
            self.model = model
            self.scaler = scaler
            self.model_name = model_name
            self.accuracy = model_accuracy
            self.use_scaled = use_scaled

        def detect_circles(self, image_path):
            """Find circles in image - exactly like reference"""
            image = cv2.imread(image_path)
            if image is None:
                raise ValueError("Could not load image")
            
            orig = image.copy()
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (7, 7), 0)
            
            circles = cv2.HoughCircles(
                gray, 
                cv2.HOUGH_GRADIENT, 
                dp=1.1,
                minDist=30,
                param1=100,
                param2=18,
                minRadius=1,
                maxRadius=80
            )
            
            if circles is None:
                raise ValueError("No circles found")
            
            circles = np.uint16(np.around(circles[0]))
            circles = sorted(circles, key=lambda x: x[0])
            
            return orig, circles

        def is_valid_circle(self, image, x, y, r):
            """Check if circle is valid - exactly like reference"""
            mask = np.zeros(image.shape[:2], dtype="uint8")
            small_radius = max(int(r * 0.5), 1)
            cv2.circle(mask, (x, y), small_radius, 255, -1)
            
            mean_bgr = cv2.mean(image, mask=mask)[:3]
            mean_bgr = np.array([[mean_bgr]], dtype=np.uint8)
            mean_hsv = cv2.cvtColor(mean_bgr, cv2.COLOR_BGR2HSV)[0][0]

            min_saturation = 100
            min_value = 100
            max_value = 300
            
            return (mean_hsv[1] >= min_saturation and 
                    min_value <= mean_hsv[2] <= max_value)

        def analyze_circles(self, image, circles):
            """Analyze circle colors - exactly like reference"""
            results = []
            circle_info = []
            valid_circles = []
            
            for i, (x, y, r) in enumerate(circles):
                if not self.is_valid_circle(image, x, y, r):
                    print(f"Circle {i+1} invalid - skipped")
                    continue
                    
                valid_circles.append((x, y, r))
                
                mask = np.zeros(image.shape[:2], dtype="uint8")
                small_radius = max(int(r * 0.5), 1)
                cv2.circle(mask, (x, y), small_radius, 255, -1)
                
                mean_rgb = cv2.mean(image, mask=mask)[:3]
                # Convert BGR to RGB for LAB conversion
                rgb_patch = np.array([mean_rgb[2], mean_rgb[1], mean_rgb[0]], dtype=np.uint8)
                lab_color = rgb_to_lab_cv(rgb_patch)
                
                results.append({
                    'Circle': i + 1,
                    'R': mean_rgb[2],
                    'G': mean_rgb[1],
                    'B': mean_rgb[0],
                    'L': lab_color[0],
                    'a': lab_color[1],
                    'b': lab_color[2]
                })
                circle_info.append((x, y, r, small_radius))
            
            return pd.DataFrame(results), circle_info, valid_circles

        def calculate_color_differences(self, df):
            """Calculate color differences - exactly like reference"""
            if len(df) < 2:
                return pd.DataFrame()
            
            bg_rgb = np.array([df.iloc[0]['R'], df.iloc[0]['G'], df.iloc[0]['B']])
            bg_lab = np.array([df.iloc[0]['L'], df.iloc[0]['a'], df.iloc[0]['b']])
            
            metrics = []
            for i in range(1, min(4, len(df))):  # Compare first 3 circles maximum
                row = df.iloc[i]
                rgb = np.array([row['R'], row['G'], row['B']])
                lab = np.array([row['L'], row['a'], row['b']])
                
                rgb_distance = np.linalg.norm(rgb - bg_rgb)
                lab_distance = np.linalg.norm(lab - bg_lab)
                de00 = ciede2000(bg_lab, lab)
                
                metrics.append({
                    'Circle': i + 1,
                    'RGB_Distance': rgb_distance,
                    'Lab_Distance': lab_distance,
                    'CIEDE2000': de00
                })
            
            return pd.DataFrame(metrics)

        def extract_features(self, diff_df):
            """Extract features from color differences - exactly like reference"""
            rgb_data = []
            lab_data = [] 
            ciede_data = []

            rgb_data.append(diff_df['RGB_Distance'].tolist())
            lab_data.append(diff_df['Lab_Distance'].tolist())
            ciede_data.append(diff_df['CIEDE2000'].tolist())

            return {
                'rgb': rgb_data,
                'lab': lab_data,
                'ciede': ciede_data
            }

        def predict(self, features):
            """Make predictions using model"""
            test_data = np.array(features['lab'])
            
            if self.use_scaled and self.scaler:
                test_data = self.scaler.transform(test_data)
            
            return self.model.predict(test_data)

class ImageProcessorApp(App):
    LOADING_ICON = "icon_loading.png"  # Place your loading icon in the icons folder
    PPB_ICON_MAP = {
        "<10": "icon_lt10.png",
        "0": "icon_lt10.png",
        "10": "icon_10.png",
        "50": "icon_50.png",
        "100": "icon_100.png",
        "warning": "warning.png"  # Added warning icon mapping
    }
    CONC_LABEL_MAP = {
        "<10": "<10 ppb",
        "0": "<10 ppb",
        "10": "10 ~ 25 ppb",
        "50": "25 ~ 75 ppb",
        "100": "> 75 ppb"
    }
    CONC_COLOR_MAP = {
        "<10 ppb": "00b050",           # green
        "10 ~ 25 ppb": "ffd700",       # yellow
        "25 ~ 75 ppb": "ff9900",       # orange
        "> 75 ppb": "ff0000"           # red 
    }
    LEVEL_MAP = {
        "<10 ppb": "Level 0",
        "10 ~ 25 ppb": "Level 1",
        "25 ~ 75 ppb": "Level 2",
        "> 75 ppb": "Level 3"
    }

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.image_path = None
        self.classifier = None
        self.prediction = None
        self.composite_image_path = None
        self.last_location = None
        self.history_dir = None
        self.history_file = None
        self.history = []
        self.control_validation_failed = False  # Track control validation status

    def build(self):
        if ANDROID:
            try:
                request_permissions([
                    Permission.READ_EXTERNAL_STORAGE,
                    Permission.WRITE_EXTERNAL_STORAGE,
                    Permission.ACCESS_FINE_LOCATION,
                    Permission.ACCESS_COARSE_LOCATION
                ])
            except Exception:
                pass

        root = BoxLayout(orientation='vertical', padding=[Window.width*0.02, Window.height*0.015], spacing=Window.height*0.01)
        menu_box = BoxLayout(orientation='horizontal', size_hint=(1, 0.09), spacing=Window.width*0.01, padding=(0,0,0,0))

        history_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "history.png")
        self.history_btn = Button(
            background_normal=history_icon_path if os.path.exists(history_icon_path) else "",
            background_down=history_icon_path if os.path.exists(history_icon_path) else "",
            size_hint=(None, None),
            size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
            pos_hint={'center_y': 0.5},
            border=(0,0,0,0),
            background_color=POPUP_BG,
            color=POPUP_FG
        )
        self.history_btn.bind(on_press=self.open_history_menu)
        menu_box.add_widget(self.history_btn)

        menu_box.add_widget(Label(size_hint=(1, 1)))

        share_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "share.png")
        self.share_icon_path = share_icon_path

        self.latest_share_btn = Button(
            background_normal=share_icon_path if os.path.exists(share_icon_path) else "",
            background_down=share_icon_path if os.path.exists(share_icon_path) else "",
            size_hint=(None, None),
            size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
            pos_hint={'center_y': 0.5},
            border=(0,0,0,0),
            disabled=False,
            background_color=POPUP_BG,
            color=POPUP_FG
        )
        self.latest_share_btn.bind(on_press=self.share_latest_analysis)
        menu_box.add_widget(self.latest_share_btn)
        root.add_widget(menu_box)

        # Add vertical space before the label and add_btn
        #root.add_widget(Widget(size_hint_y=0.04))

        # Move 'As sensor' and add_btn lower with better spacing
        as_sensor_box = BoxLayout(
            orientation='vertical', 
            size_hint=(1, None), 
            height=Window.height*0.28,  # More height for better spacing
            spacing=dp(15),  # Increased spacing
            padding=[dp(10), dp(5), dp(10), dp(5)]  # Add padding around the box
        )
        as_sensor_box.add_widget(Widget(size_hint_y=None, height=dp(10)))
        as_sensor_box.add_widget(Label(
            text='[color=ff0000]AS[/color][color=000000]SESSOR[/color]',
            size_hint=(1, None),
            height=dp(70),  # Larger fixed height
            font_size=sp(56),  # Even larger font
            halign='center',
            valign='middle',
            color=POPUP_FG,
            markup=True,
            text_size=(None, None)  # Allow text to use full space
        ))

        #spacer = Widget(size_hint=(1, 0.08))  # Takes 30% of remaining space
        #as_sensor_box.add_widget(spacer)
        as_sensor_box.add_widget(Widget(size_hint_y=None, height=dp(5)))
        self.add_btn = RectangularPlusButton(
            size_hint=(1, None),
            height=Window.height * 0.12,
        )
        #self.add_btn.bind(on_press=self.open_file_chooser)
        self.add_btn.bind(on_press=self.on_add_button_pressed)


        as_sensor_box.add_widget(self.add_btn)
        root.add_widget(as_sensor_box)      
        
        # --- START RESULT FEEDBACK AREA ---
        # The following widgets show status and results below the Load Image button and above the icon.
        # You can exclude or comment out this block to remove result feedback display from your app.

        # Status label for messages like "Image loaded", "Processing...", etc.
        #self.status_label = Label(text='', size_hint=(1, 0.035), font_size=sp(13), markup=True, color=POPUP_FG)
        #root.add_widget(self.status_label)

        # Result display label for arsenic concentration, color-coded and formatted
        #self.result_display = Label(text='', size_hint=(1, 0.045), font_size=sp(13), markup=True, color=POPUP_FG)
        #root.add_widget(self.result_display)
        # --- END RESULT FEEDBACK AREA ---

        # This area displays the icon for prediction result (ppb level)
        loading_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", self.LOADING_ICON)
        # Add small vertical space
        root.add_widget(Widget(size_hint_y=None, height=dp(25)))
        
        # Create container for icon with padding
        icon_container = BoxLayout(
            orientation='vertical',
            size_hint=(1, 0.32),
            padding=[dp(20), dp(15), dp(20), dp(15)],  # left, top, right, bottom padding
            spacing=0
        )
        
        self.ppb_icon = KivyImage(size_hint=(1, 1), allow_stretch=True, keep_ratio=True)
        self.ppb_icon.source = loading_icon_path if os.path.exists(loading_icon_path) else ''
        self.ppb_icon.reload()
        
        icon_container.add_widget(self.ppb_icon)
        root.add_widget(icon_container)
        # Add vertical space after the icon
        root.add_widget(Widget(size_hint_y=None, height=dp(25)))

        if ANDROID:
            try:
                ext_dir = os.path.join(primary_external_storage_path(), "ArsenicSensorHistory")
                os.makedirs(ext_dir, exist_ok=True)
                self.history_dir = ext_dir
            except Exception:
                app_dir = os.path.dirname(os.path.abspath(__file__))
                self.history_dir = os.path.join(app_dir, "history")
        else:
            app_dir = os.path.dirname(os.path.abspath(__file__))
            self.history_dir = os.path.join(app_dir, "history")
        self.history_file = os.path.join(self.history_dir, "history.json")
        os.makedirs(self.history_dir, exist_ok=True)
        self.load_history()

        if ANDROID:
            Clock.schedule_interval(lambda dt: self.optimize_memory(), 300)
            Clock.schedule_once(lambda dt: self.optimize_memory(), 2)

        Clock.schedule_once(lambda dt: self.auto_load_model(), 0.1)
        return root
    

    def prompt_image_source(self):
        """Show popup to choose between gallery and camera - big icons only with proper alignment"""
        print("prompt_image_source called!")
        
        # Back button - using your working approach with fallback
        back_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "back.png")
        if os.path.exists(back_icon_path):
            back_btn = Button(
                background_normal=back_icon_path,
                background_down=back_icon_path,
                size_hint=(None, None),
                size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
                border=(0,0,0,0),
                background_color=POPUP_BG,
                color=POPUP_FG
            )
        else:
            back_btn = Button(
                text="←",
                size_hint=(None, None),
                size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
                background_color=(0.7, 0.7, 0.7, 1),  # Gray background
                color=(0, 0, 0, 1),  # Black text
                font_size=sp(18)
            )
        
        # Horizontal rectangular layout
        content = BoxLayout(orientation='vertical', padding=[dp(12), dp(12), dp(12), dp(18)], spacing=dp(10))
        
        # Top section - back button left aligned
        top_section = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(40))
        top_section.add_widget(back_btn)
        top_section.add_widget(Widget())  # Right spacer to push back button left
        
        # Bottom section - icons centered
        bottom_section = BoxLayout(orientation='vertical')
        
        # Icons in horizontal layout - centered
        icons_anchor = AnchorLayout(anchor_x='center', anchor_y='center')
        icons_inner = BoxLayout(
            orientation='horizontal',
            spacing=dp(40),
            size_hint=(None, None),
            height=ICON_SIZE_LARGE
        )
        # Gallery icon - using your working approach with fallback
        gallery_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "gallery.png")
        if os.path.exists(gallery_icon_path):
            gallery_btn = Button(
                background_normal=gallery_icon_path,
                background_down=gallery_icon_path,
                size_hint=(None, None),
                size=(ICON_SIZE_LARGE, ICON_SIZE_LARGE),
                border=(0,0,0,0),
                background_color=POPUP_BG,
                color=POPUP_FG
            )
        else:
            gallery_btn = Button(
                text="Gallery",
                size_hint=(None, None),
                size=(ICON_SIZE_LARGE, ICON_SIZE_LARGE),
                background_color=(0.3, 0.6, 0.9, 1),  # Blue background
                color=(1, 1, 1, 1),  # White text
                font_size=sp(12)
            )
        
        # Camera icon - using your working approach with fallback
        camera_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "camera.png")
        if os.path.exists(camera_icon_path):
            camera_btn = Button(
                background_normal=camera_icon_path,
                background_down=camera_icon_path,
                size_hint=(None, None),
                size=(ICON_SIZE_LARGE, ICON_SIZE_LARGE),
                border=(0,0,0,0),
                background_color=POPUP_BG,
                color=POPUP_FG
            )
        else:
            camera_btn = Button(
                text="Camera",
                size_hint=(None, None),
                size=(ICON_SIZE_LARGE, ICON_SIZE_LARGE),
                background_color=(0.9, 0.3, 0.3, 1),  # Red background
                color=(1, 1, 1, 1),  # White text
                font_size=sp(12)
            )
        
        # Add icons to inner layout
        icons_inner.add_widget(gallery_btn)
        icons_inner.add_widget(camera_btn)
        icons_inner.width = ICON_SIZE_LARGE + dp(40) + ICON_SIZE_LARGE  # Calculate width
        
        # Add to anchor layout
        icons_anchor.add_widget(icons_inner)
        
        # Build bottom section
        bottom_section.add_widget(icons_anchor)
        
        # Add sections to main content
        content.add_widget(top_section)
        content.add_widget(bottom_section)
        
        # Create horizontal rectangular popup 
        popup = SkyBluePopup(title="", content=content, size_hint=(0.8, 0.25), auto_dismiss=False)
        
        # Callback functions
        def on_gallery(instance):
            print("Gallery selected")
            popup.dismiss()
            Clock.schedule_once(lambda dt: self.open_file_chooser(), 0.1)
        
        def on_camera(instance):
            print("Camera selected") 
            popup.dismiss()
            Clock.schedule_once(lambda dt: self.open_camera_jnius(), 0.1)
        
        def on_cancel(instance):
            print("Selection cancelled")
            popup.dismiss()
        
        # Bind events
        gallery_btn.bind(on_press=on_gallery)
        camera_btn.bind(on_press=on_camera)
        back_btn.bind(on_press=on_cancel)
        
        popup.open()

    def _show_popup(self, title, message):
        """Show popup with consistent styling and proper text alignment"""
        
        content = BoxLayout(orientation='vertical', padding=[dp(18), dp(12), dp(18), dp(12)], spacing=dp(12))
        
        back_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "back.png")
        if os.path.exists(back_icon_path):
            back_btn = Button(
                background_normal=back_icon_path,
                background_down=back_icon_path,
                size_hint=(None, None),
                size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
                background_color=POPUP_BG,
                border=(0,0,0,0),
                padding=(0,0)
            )
        else:
            back_btn = Button(
                text="←",
                size_hint=(None, None),
                size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
                background_color=(0.7, 0.7, 0.7, 1),  # Gray background
                color=(0, 0, 0, 1),  # Black text
                font_size=sp(18),
                border=(0,0,0,0),
                padding=(0,0)
            )
        
        # Title label with proper alignment
        title_label = Label(
            text=f"[b]{title}[/b]", 
            markup=True, 
            font_size=sp(20), 
            halign='center', 
            valign='middle', 
            color=POPUP_FG,
            text_size=(None, None)
        )
        
        title_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(54), spacing=dp(10))
        title_row.add_widget(back_btn)
        title_row.add_widget(title_label)
        title_row.add_widget(Widget(size_hint=(None, None), size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL)))
        
        content.add_widget(title_row)
        content.add_widget(Divider())
        
        # Message label with proper alignment and sizing
        message_label = Label(
            text=message, 
            markup=True, 
            halign='center', 
            valign='middle', 
            font_size=sp(16), 
            color=POPUP_FG,
            text_size=(None, None)
        )
        # Bind the text_size to the label width for proper text wrapping when needed
        message_label.bind(width=lambda instance, value: setattr(instance, 'text_size', (value, None)))
        
        content.add_widget(message_label)
        
        popup = SkyBluePopup(title="", content=content, size_hint=(0.85, 0.4), auto_dismiss=False)
        back_btn.bind(on_press=popup.dismiss)
        popup.open()

    def on_add_button_pressed(self, instance):
        """Handler for add button press - ALWAYS shows popup"""
        print(f"Add button pressed! Instance: {instance}")
        self.prompt_image_source()

    # Keep your optimized camera methods unchanged
    def open_camera_jnius(self):
        """Open camera with optimized Android handling"""
        if platform != "android":
            self._show_popup("Camera Not Supported", "Camera only works on Android.")
            return

        try:
            request_permissions([Permission.CAMERA, Permission.WRITE_EXTERNAL_STORAGE])

            if not hasattr(self, '_camera_classes_cached'):
                self.PythonActivity = autoclass('org.kivy.android.PythonActivity')
                self.Intent = autoclass('android.content.Intent')
                self._camera_classes_cached = True

            intent = self.Intent("android.media.action.IMAGE_CAPTURE")
            
            print("Launching optimized camera...")
            currentActivity = cast('android.app.Activity', self.PythonActivity.mActivity)
            activity.bind(on_activity_result=self.on_activity_result_bitmap)
            currentActivity.startActivityForResult(intent, 1001)
            
        except Exception as e:
            print(f"Camera error: {e}")
            self._show_popup("Camera Error", f"Failed to open camera: {str(e)}")

    @mainthread  
    def on_activity_result_bitmap(self, requestCode, resultCode, intent_result):
        """Optimized activity result handler"""
        activity.unbind(on_activity_result=self.on_activity_result_bitmap)
        
        print(f"Camera result: requestCode={requestCode}, resultCode={resultCode}")
        
        if requestCode == 1001 and resultCode == -1:  # RESULT_OK
            if intent_result is not None:
                try:
                    print("Processing camera result...")
                    extras = intent_result.getExtras()
                    
                    if extras is not None:
                        bitmap = extras.get("data")
                        if bitmap is not None:
                            print("Found bitmap data!")
                            self.save_bitmap_to_file(bitmap)
                            return
                    
                    print("No bitmap data, searching recent files...")
                    self.find_very_recent_image()
                    
                except Exception as e:
                    print(f"Error processing result: {e}")
                    self.find_very_recent_image()
            else:
                self.find_very_recent_image()
        else:
            self._show_popup("Camera Cancelled", "No photo was taken.")

    def save_bitmap_to_file(self, bitmap):
        """Optimized bitmap saving with better error handling"""
        try:
            if not hasattr(self, '_file_classes_cached'):
                self.Environment = autoclass('android.os.Environment')
                self.File = autoclass('java.io.File')
                self.FileOutputStream = autoclass('java.io.FileOutputStream')
                self.BitmapCompressFormat = autoclass('android.graphics.Bitmap$CompressFormat')
                self._file_classes_cached = True
            
            timestamp = int(datetime.datetime.now().timestamp())
            filename = f"camera_{timestamp}.jpg"
            
            context = cast('android.content.Context', self.PythonActivity.mActivity)
            external_files_dir = context.getExternalFilesDir(self.Environment.DIRECTORY_PICTURES)
            
            if external_files_dir is None:
                external_files_dir = context.getFilesDir()
            
            file_obj = self.File(external_files_dir, filename)
            file_path = file_obj.getAbsolutePath()
            
            fos = self.FileOutputStream(file_obj)
            bitmap.compress(self.BitmapCompressFormat.JPEG, 95, fos)
            fos.close()
            
            print(f"Bitmap saved to: {file_path}")
            
            if os.path.exists(file_path):
                self.image_selected(file_path)
            else:
                self._show_popup("Camera Error", "Failed to save camera image")
                
        except Exception as e:
            print(f"Error saving bitmap: {e}")
            self._show_popup("Camera Error", f"Failed to save image: {e}")

    def find_very_recent_image(self):
        """Optimized recent image search"""
        try:
            print("Searching for recent images...")
            
            camera_dirs = [
                "/storage/emulated/0/DCIM/Camera",
                "/storage/emulated/0/DCIM",
            ]
            
            try:
                Environment = autoclass('android.os.Environment')
                system_camera_dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).getAbsolutePath()
                camera_dirs.extend([
                    system_camera_dir + "/Camera",
                    system_camera_dir
                ])
            except:
                pass
            
            current_time = datetime.datetime.now().timestamp()
            most_recent_file = None
            most_recent_time = 0
            
            for dir_path in camera_dirs:
                if os.path.exists(dir_path):
                    try:
                        files = [f for f in os.listdir(dir_path) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
                        
                        for filename in files:
                            file_path = os.path.join(dir_path, filename)
                            file_time = os.path.getmtime(file_path)
                            age = current_time - file_time
                            
                            if age < 30:
                                if file_time > most_recent_time:
                                    most_recent_time = file_time
                                    most_recent_file = file_path
                                    
                    except Exception as e:
                        print(f"Error checking {dir_path}: {e}")
                        continue
            
            if most_recent_file:
                print(f"Found recent image: {most_recent_file}")
                self.image_selected(most_recent_file)
            else:
                self._show_popup("Photo Taken", "Photo captured! Please use Gallery to select it.")
                
        except Exception as e:
            print(f"Error finding recent image: {e}")
            self._show_popup("Camera Error", f"Could not locate image: {e}")


    def open_file_chooser(self, instance=None, cb=None):
        def handle_selection(selection):
            if selection and len(selection) > 0 and os.path.isfile(selection[0]):
                if cb:
                    Clock.schedule_once(lambda dt: cb(selection[0]), 0)
                else:
                    Clock.schedule_once(lambda dt: self.image_selected(selection[0]), 0)

        if ANDROID:
            try:
                plyer_filechooser.open_file(title='Choose Image', on_selection=handle_selection)
            except Exception as e:
                print(f"Android file chooser failed: {e}")
                self._open_desktop_file_chooser(cb)
        else:
            self._open_desktop_file_chooser(cb)


    def _open_desktop_file_chooser(self, cb=None):
        import time
        class DoubleTapFileChooser(FileChooserListView):
            last_touch_time = 0
            last_selection = None
            DOUBLE_TAP_TIME = 0.35
            def on_touch_up(self, touch):
                if self.collide_point(*touch.pos):
                    if self.selection and len(self.selection) > 0 and os.path.isfile(self.selection[0]):
                        now = time.time()
                        if (
                            self.last_selection == self.selection[0]
                            and now - self.last_touch_time < self.DOUBLE_TAP_TIME
                        ):
                            if cb:
                                cb(self.selection[0])
                            else:
                                App.get_running_app().image_selected(self.selection[0])
                            popup.dismiss()
                            self.last_touch_time = 0
                            self.last_selection = None
                            return True
                        else:
                            self.last_touch_time = now
                            self.last_selection = self.selection[0]
                return super().on_touch_up(touch)
        content = BoxLayout(orientation='vertical', padding=[dp(18), dp(12), dp(18), dp(12)], spacing=dp(14))
        file_chooser = DoubleTapFileChooser(filters=['*.png', '*.jpg', '*.jpeg', '*.bmp'], size_hint=(1, 1))
        content.add_widget(Label(text="Double-tap an image file to select", font_size=sp(20), color=POPUP_FG, size_hint_y=None, height=dp(34)))
        content.add_widget(file_chooser)
        back_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "back.png")
        btn_box = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(52), spacing=dp(18), padding=(0, dp(4), 0, 0))
        back_btn = Button(
            background_normal=back_icon_path if os.path.exists(back_icon_path) else "",
            background_down=back_icon_path if os.path.exists(back_icon_path) else "",
            size_hint=(None, None),
            size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
            background_color=POPUP_BG,
            border=(0,0,0,0),
            padding=(0,0),
            color=POPUP_FG
        )
        popup = SkyBluePopup(title='', content=content, size_hint=(0.95, 0.95))
        back_btn.bind(on_press=lambda x: popup.dismiss())
        btn_box.add_widget(back_btn)
        content.add_widget(BoxLayout(size_hint_y=None, height=dp(4)))
        content.add_widget(btn_box)
        popup.open()

    def image_selected(self, selected_file):
        def update_ui(dt):
            self.image_path = selected_file
            
            if os.path.exists(selected_file):
                # Find the parent container
                parent = self.add_btn.parent
                if parent:
                    # Remove the old plus button
                    parent.remove_widget(self.add_btn)
                    
                    # Create a new container with image
                    button_container = BoxLayout(orientation='vertical', size_hint=(1, None), height=Window.height * 0.12)
                    
                    # Create image widget that fills the space better
                    image_widget = KivyImage(
                        source=selected_file,
                        size_hint=(1, 1),
                        allow_stretch=True,
                        keep_ratio=True,
                    )
                    
                    # Add border
                    with button_container.canvas.before:
                        Color(0, 0, 0, 1)  # Black border
                        border_line = Line(width=dp(1))  # Use same width as RectangularPlusButton
                    
                    def update_border(*args):
                        border_line.width = dp(1)  # Keep consistent border width
                        border_line.rectangle = (button_container.x, button_container.y, 
                                            button_container.width, button_container.height)
                    
                    button_container.bind(pos=update_border, size=update_border)
                    
                    # Add click functionality directly to the container
                    def on_container_touch(instance, touch):
                        if instance.collide_point(*touch.pos):
                            self.prompt_image_source()  # ← FIXED: Now calls popup first
                            return True
                        return False

                    
                    button_container.bind(on_touch_down=on_container_touch)
                    
                    # Add only the image to container
                    button_container.add_widget(image_widget)
                    
                    # Add to parent
                    parent.add_widget(button_container)
                    
                    # Update reference
                    self.add_btn = button_container
                    
                    # Schedule border update
                    Clock.schedule_once(lambda dt: update_border(), 0.1)
            
            #self.result_display.text = ""
            # Reset control validation state and clear icon when new image selected
            self.control_validation_failed = False
            self.ppb_icon.source = ""
            if self.classifier:
                Clock.schedule_once(lambda dt: self.process_image(), 0.2)
        
        Clock.schedule_once(update_ui, 0)

    def auto_load_model(self):
        app_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
        jsons = [f for f in os.listdir(app_dir) if f.lower().endswith('.json')]
        if not jsons:
            #self.status_label.text = "[color=ff0000]No model found in app directory.[/color]"
            self.classifier = None
            return
        model_path = os.path.join(app_dir, jsons[0])
        try:
            with open(model_path, "r", encoding="utf-8") as f:
                model_data = json.load(f)
            weights = model_data.get('weights')
            biases = model_data.get('biases')
            activation = model_data.get('activation', 'relu')
            classes = model_data.get('classes')
            scaler_mean = model_data.get('scaler_mean')
            scaler_scale = model_data.get('scaler_scale')
            use_scaled = model_data.get('use_scaled', True)
            model_name = os.path.basename(jsons[0])
            model_accuracy = model_data.get('cv_accuracy')
            
            if weights and biases and classes and scaler_mean and scaler_scale:
                mlp_model = MLPModel(weights, biases, activation, classes)
                scaler = SimpleScaler(scaler_mean, scaler_scale)
                self.classifier = ImageClassifier(mlp_model, scaler, model_name, model_accuracy, use_scaled)
            else:
                self.classifier = None
        except Exception as e:
            #self.status_label.text = f"[color=ff0000]Error loading model: {e}[/color]"
            self.classifier = None

    def process_image(self, *args):
        """Optimized image processing with background thread"""
        if not self.image_path or not self.classifier:
            return
        
        # Show loading indicator
        self.show_loading_indicator()
        
        # Process in background thread to avoid blocking UI
        def process_in_background():
            try:
                result_queue = queue.Queue()
                
                def processing_worker():
                    try:
                        # Step 1: Detect circles
                        print("Step 1: Detecting circles...")
                        image, circles = self.classifier.detect_circles(self.image_path)
                        print(f"Found {len(circles)} circles")

                        # Step 2: Analyze colors
                        print("Step 2: Analyzing colors...")
                        color_data, circle_info, valid_circles = self.classifier.analyze_circles(image, circles)
                        print(f"Found {len(valid_circles)} valid circles")

                        if len(valid_circles) == 0:
                            result_queue.put({'error': "No valid circles found"})
                            return

                        # Step 2.5: Control validation using only Lab-a values
                        print("Step 2.5: Validating controls (Lab-a thresholds)...")
                        if len(color_data) >= 2:
                            # Get leftmost and rightmost circles based on their position (x-coordinate)
                            sorted_indices = sorted(range(len(color_data)), key=lambda i: valid_circles[i][0])
                            leftmost_idx = sorted_indices[0]
                            rightmost_idx = sorted_indices[-1]

                            leftmost_lab_a = color_data.iloc[leftmost_idx]['a']
                            rightmost_lab_a = color_data.iloc[rightmost_idx]['a']

                            # Control conditions: leftmost (yellow) should be <10, rightmost (pink) should be >45
                            if leftmost_lab_a >= 10 or rightmost_lab_a <= 45:
                                error_msg = (
                                    #"Control validation failed: Not enough separation between controls (Lab-a only).\n"
                                    #f"Leftmost (yellow) Lab-a: {leftmost_lab_a:.3f} (should be < 10)\n"
                                    #f"Rightmost (pink) Lab-a: {rightmost_lab_a:.3f} (should be > 45)\n"
                                )

                                warning_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "warning.png")

                                def set_warning_icon(_):
                                    if hasattr(self, 'ppb_icon'):
                                        self.control_validation_failed = True
                                        if os.path.exists(warning_icon_path):
                                            self.ppb_icon.source = warning_icon_path
                                        else:
                                            print(f"Warning icon not found at: {warning_icon_path}")
                                            self.ppb_icon.source = warning_icon_path
                                        self.ppb_icon.reload()

                                Clock.schedule_once(set_warning_icon, 0)
                                result_queue.put({'error': error_msg})
                                return

                        # Step 3: Calculate color differences
                        print("Step 3: Calculating color differences...")
                        color_diffs = self.classifier.calculate_color_differences(color_data)

                        if len(color_diffs) == 0:
                            result_queue.put({'error': "No color differences calculated - need at least 2 valid circles"})
                            return

                        # Step 4: Extract features
                        print("Step 4: Extracting features...")
                        features = self.classifier.extract_features(color_diffs)

                        # Step 5: Make predictions
                        print("Step 5: Making predictions...")
                        predictions = self.classifier.predict(features)
                        
                        pred = str(predictions[0])
                        
                        # Prepare result data
                        result_data = {
                            'prediction': pred,
                            'image': image,
                            'valid_circles': valid_circles,
                            'circle_info': circle_info,
                            'rgb_distances': color_diffs['RGB_Distance'].tolist(),
                            'lab_distances': color_diffs['Lab_Distance'].tolist(),
                            'ciede_distances': color_diffs['CIEDE2000'].tolist()
                        }
                        
                        result_queue.put({'success': result_data})
                        
                    except Exception as e:
                        result_queue.put({'error': str(e)})
                
                # Start processing thread
                thread = Thread(target=processing_worker)
                thread.daemon = True
                thread.start()
                
                # Wait for result with timeout
                import time
                timeout = 30 if ANDROID else 60  # Shorter timeout for mobile
                start_time = time.time()
                
                while thread.is_alive() and (time.time() - start_time) < timeout:
                    time.sleep(0.1)
                
                if thread.is_alive():
                    result_queue.put({'error': "Processing timeout"})
                
                # Get result
                try:
                    result = result_queue.get_nowait()
                except queue.Empty:
                    result = {'error': "No result received"}
                
                # Schedule UI update on main thread
                Clock.schedule_once(lambda dt: self.process_image_complete(result), 0)
                
            except Exception as e:
                Clock.schedule_once(lambda dt: self.process_image_complete({'error': str(e)}), 0)
        
        # Start background processing
        thread = Thread(target=process_in_background)
        thread.daemon = True
        thread.start()

    @mainthread
    def process_image_complete(self, result):
        """Handle processing completion on main thread"""
        self.hide_loading_indicator()
        
        if 'error' in result:
            print(f"Processing failed: {result['error']}")
            # Only clear icon if control validation didn't fail (warning icon should persist)
            if not self.control_validation_failed:
                self.ppb_icon.source = ""
            self.latest_share_btn.disabled = False
            return
        
        # Extract successful result data
        data = result['success']
        pred = data['prediction']
        self.prediction = pred
        
        # Show appropriate icon
        icon_path = None
        icon_filename = self.PPB_ICON_MAP.get(pred)
        if icon_filename:
            app_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
            icon_path = os.path.join(app_dir, "icons", icon_filename)
        if icon_path and os.path.exists(icon_path):
            self.ppb_icon.source = icon_path
        else:
            self.ppb_icon.source = ""

        # Create visualization and composite in background
        def create_output_images():
            try:
                out_dir = self.history_dir
                timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
                base_name = os.path.splitext(os.path.basename(self.image_path))[0]
                processed_img_path = os.path.join(out_dir, f"{base_name}_{timestamp}_processed.png")
                
                self.save_processed_image(data['image'], data['valid_circles'], 
                                        data['circle_info'], processed_img_path)
                
                comp_path = os.path.join(out_dir, f"{base_name}_{timestamp}_composite.png")
                self.get_location_and_make_composite(self.image_path, processed_img_path, 
                                                   pred, comp_path, timestamp)
                
                # Update UI on main thread
                Clock.schedule_once(lambda dt: setattr(self, 'composite_image_path', comp_path), 0)
                Clock.schedule_once(lambda dt: setattr(self.latest_share_btn, 'disabled', False), 0)
                
            except Exception as e:
                print(f"Error creating output images: {e}")
        
        # Create output images in background
        thread = Thread(target=create_output_images)
        thread.daemon = True
        thread.start()
        
        print(f"Processing completed: {pred}")

    def show_loading_indicator(self):
        """Show loading indicator"""
        if hasattr(self, 'ppb_icon'):
            loading_icon_path = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), 
                                           "icons", self.LOADING_ICON)
            if os.path.exists(loading_icon_path):
                self.ppb_icon.source = loading_icon_path
            else:
                # Create a simple loading animation with text
                self.result_display.text = "[b]Processing...[/b]"

    def hide_loading_indicator(self):
        """Hide loading indicator"""
        if hasattr(self, 'result_display'):
            self.result_display.text = ""

    def save_processed_image(self, img_cv, valid_circles, circle_info, save_path):
        """Save visualization image exactly like reference"""
        vis = img_cv.copy()
        for i, (x, y, r, small_r) in enumerate(circle_info):
            cv2.circle(vis, (x, y), r, (0, 255, 255), 2)  # Yellow outer circle
            cv2.circle(vis, (x, y), small_r, (255, 0, 255), 1)  # Magenta inner circle
            cv2.putText(vis, str(i + 1), (x - 10, y - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.imwrite(save_path, vis)


    def get_location_and_make_composite(self, orig_path, processed_path, prediction, out_path, timestamp):
        def _with_location(location):
            self.make_composite_image(orig_path, processed_path, prediction, out_path, location, timestamp)
        if ANDROID:
            location = get_android_location()
            if location and location['latitude'] is not None and location['longitude'] is not None:
                _with_location(location)
            else:
                _with_location({'latitude': 40.7128, 'longitude': -74.0060})
        elif os.name == "nt":  # Windows
            lat, lon = get_windows_location()
            if lat is not None and lon is not None:
                _with_location({'latitude': lat, 'longitude': lon})
            else:
                _with_location({'latitude': 40.7128, 'longitude': -74.0060})
        else:
            _with_location({'latitude': 40.7128, 'longitude': -74.0060})


    def make_composite_image(self, orig_path, processed_path, prediction, out_path, location=None, timestamp=None):
        """Optimized composite image creation with larger pump icon and dynamic metadata sizing"""
        try:
            # Load and resize images efficiently
            orig = Image.open(orig_path).convert("RGB")
            proc = Image.open(processed_path).convert("RGB")
            
            # Smaller dimensions for mobile performance
            max_img_width = 300 if ANDROID else 400
            max_img_height = 200 if ANDROID else 300
            
            # Resize images using fast function
            orig = resize_image_fast(orig, max_img_width, max_img_height)
            proc = resize_image_fast(proc, max_img_width, max_img_height)
            
            orig_w, orig_h = orig.size
            proc_w, proc_h = proc.size
            
            # Compact dimensions for mobile
            image_width = max(orig_w, proc_w)
            composite_w = max(image_width, 300) + 30
            
            # Reduced padding for mobile
            pad_top = 20 if ANDROID else 25
            pad_between = 10 if ANDROID else 15
            pad_side = 15 if ANDROID else 20
            pad_bottom = 20 if ANDROID else 25
            
            # Larger icon sizing for better visibility
            if ANDROID:
                icon_width = min(int(composite_w * 0.4), 150)
                icon_height = min(int(icon_width * 0.75), 100)
            else:
                icon_width = min(int(composite_w * 0.35), 200)
                icon_height = min(int(icon_width * 0.75), 150)
            
            # Load icon with improved quality
            pump_icon_path = self._get_pump_icon_path()
            
            pump_img = None
            if os.path.exists(pump_icon_path):
                try:
                    cache_key = f"pump_icon_{icon_width}_{icon_height}"
                    if cache_key in _image_cache:
                        pump_img = _image_cache[cache_key]
                    else:
                        original_icon = Image.open(pump_icon_path).convert("RGBA")
                        pump_img = original_icon.resize(
                            (icon_width, icon_height), 
                            Image.LANCZOS
                        )
                        _image_cache[cache_key] = pump_img
                        
                except Exception as e:
                    print(f"Error loading pump icon: {e}")
                    pump_img = None
            
            # Font sizes optimized for mobile
            base_font_size = 14 if ANDROID else 20
            large_font_size = 20 if ANDROID else 32
            header_font_size = 12 if ANDROID else 18
            
            # Load fonts efficiently
            base_font = get_cached_font(base_font_size)
            large_font = get_cached_font(large_font_size)
            header_font = get_cached_font(header_font_size)
            
            # IMPROVED: Calculate actual metadata content height dynamically
            line_height = base_font_size + 4
            metadata_padding = 20  # Internal padding for metadata box
            
            # Prepare data first to calculate required space
            if timestamp:
                dt_obj = datetime.datetime.strptime(timestamp, "%Y%m%d_%H%M%S")
            else:
                dt_obj = datetime.datetime.now()
            
            time_str = dt_obj.strftime("%Y-%m-%d %H:%M")
            location_str = self._format_location_short(location)
            result_label, result_color = self._get_prediction_display(prediction)
            
            # Calculate required height for metadata content
            if ANDROID:
                # Mobile: 3 lines + result box
                content_lines = 3  # Time, Location, Result
                result_height = get_text_size_fast(result_label, base_font)[1]
                metadata_content_height = (content_lines * (line_height + 4)) + result_height + 10
            else:
                # Desktop: 6 text lines + result box
                content_lines = 6  # "Time:", time_str, "Location:", location_str, "Result:", result_label
                result_height = get_text_size_fast(result_label, large_font)[1]
                metadata_content_height = (content_lines * (line_height + 4)) + result_height + 15
            
            # Final metadata box height = content + padding
            metadata_height = metadata_content_height + metadata_padding
            
            # Calculate total height with dynamic metadata
            composite_h = (pad_top + icon_height + pad_between +
                        orig_h + pad_between + proc_h + pad_between +
                        metadata_height + pad_bottom)
            
            # Create composite
            composite = Image.new("RGB", (composite_w, composite_h), (255, 255, 255))
            draw = ImageDraw.Draw(composite)
            
            current_y = pad_top
            
            # 1. Draw pump icon or text with improved positioning
            '''
            icon_x = (composite_w - icon_width) // 2
            if pump_img:
                composite.paste(pump_img, (icon_x, current_y), pump_img)
            else:
                # Fallback text with better styling
                text = "PUMP"
                text_width, text_height = get_text_size_fast(text, large_font)
                text_x = (composite_w - text_width) // 2
                
                # Add background rectangle for better visibility
                padding = 8
                rect_x1 = text_x - padding
                rect_y1 = current_y - padding
                rect_x2 = text_x + text_width + padding
                rect_y2 = current_y + text_height + padding
                
                draw.rectangle([rect_x1, rect_y1, rect_x2, rect_y2], 
                            fill=(240, 240, 240), outline=(100, 100, 100), width=2)
                draw.text((text_x, current_y), text, fill=(0, 0, 0), font=large_font)
            
            current_y += icon_height + pad_between
            '''
            # 2. Place images
            orig_x = (composite_w - orig_w) // 2
            composite.paste(orig, (orig_x, current_y))
            current_y += orig_h + pad_between
            
            proc_x = (composite_w - proc_w) // 2
            composite.paste(proc, (proc_x, current_y))
            current_y += proc_h + pad_between
            
            # 3. IMPROVED: Dynamic metadata section with vertical centering
            metadata_box_x = pad_side
            metadata_box_y = current_y
            metadata_box_w = composite_w - (2 * pad_side)
            metadata_box_h = metadata_height  # Now calculated dynamically
            
            # Draw metadata border
            #draw.rectangle([metadata_box_x, metadata_box_y, 
            #            metadata_box_x + metadata_box_w, 
            #            metadata_box_y + metadata_box_h], 
            #            fill=None, outline=(0, 0, 0), width=1)
            
            # NEW: Calculate actual content height for vertical centering
            def calculate_actual_content_height():
                if ANDROID:
                    # Mobile: 3 lines + result box
                    line_count = 3
                    result_height = get_text_size_fast(result_label, base_font)[1]
                    return (line_count * (line_height + 4)) + result_height - 4  # Remove last spacing
                else:
                    # Desktop: 6 lines + result box  
                    line_count = 6
                    result_height = get_text_size_fast(result_label, large_font)[1]
                    return (line_count * (line_height + 4)) + result_height + 8  # Extra spacing
            
            actual_content_height = calculate_actual_content_height()
            
            # NEW: Calculate vertical centering offset
            available_vertical_space = metadata_box_h - 20  # Subtract top/bottom padding
            vertical_offset = max(10, (available_vertical_space - actual_content_height) // 2)
            
            # NEW: Start drawing from vertically centered position
            text_x = metadata_box_x + 10
            text_y = metadata_box_y + vertical_offset  # Use centered position instead of fixed +10
            
            # Compact layout based on platform
            if ANDROID:
                # Single line format for mobile - more compact
                draw.text((text_x, text_y), f"Time: {time_str}", fill=(0, 0, 0), font=base_font)
                text_y += line_height + 4
                
                draw.text((text_x, text_y), f"Location: {location_str}", fill=(0, 0, 0), font=base_font)
                text_y += line_height + 6
                
                # Result with highlight box, centered vertically in the box
                result_width, result_height = get_text_size_fast(result_label, base_font)
                box_padding = 3
                box_x1 = text_x - box_padding
                box_y1 = text_y - box_padding
                box_x2 = text_x + result_width + box_padding
                box_y2 = text_y + result_height + box_padding

                draw.rectangle([box_x1, box_y1, box_x2, box_y2],
                               fill=(255, 255, 255), outline=result_color, width=1)

                # Center the result text vertically in the box
                box_center_y = (box_y1 + box_y2) // 2
                text_y_centered = box_center_y - result_height // 2
                draw.text((text_x, text_y_centered), result_label, fill=(0, 0, 0), font=base_font)
                
            else:
                # Desktop format with proper spacing
                draw.text((text_x, text_y), "Time:", fill=(80, 80, 80), font=header_font)
                text_y += line_height + 2
                draw.text((text_x, text_y), time_str, fill=(0, 0, 0), font=base_font)
                text_y += line_height + 8
                
                draw.text((text_x, text_y), "Location:", fill=(80, 80, 80), font=header_font)
                text_y += line_height + 2
                draw.text((text_x, text_y), location_str, fill=(0, 0, 0), font=base_font)
                text_y += line_height + 8
                
                draw.text((text_x, text_y), "Result:", fill=(80, 80, 80), font=header_font)
                text_y += line_height + 4
                
                result_width, result_height = get_text_size_fast(result_label, large_font)
                box_padding = 6
                box_x1 = text_x - box_padding
                box_y1 = text_y - box_padding
                box_x2 = text_x + result_width + box_padding
                box_y2 = text_y + result_height + box_padding
                
                draw.rectangle([box_x1, box_y1, box_x2, box_y2], 
                            fill=(255, 255, 255), outline=result_color, width=2)
                draw.text((text_x, text_y), result_label, fill=(0, 0, 0), font=large_font)
            
            # Save with high quality settings
            save_quality = 95
            composite.save(out_path, format="JPEG", quality=save_quality, optimize=True)
            self.save_to_history(prediction, dt_obj.strftime("%Y-%m-%d %H:%M:%S"), out_path)
            
            # Cleanup
            del composite, draw
            if pump_img and cache_key not in _image_cache:
                del pump_img
            gc.collect()
            
            print(f"Optimized composite with dynamic metadata sizing saved to {out_path}")

        except Exception as e:
            print(f"Failed to make composite image: {e}")

    def optimize_memory(self):
        """Optimize memory usage by clearing caches periodically"""
        # Clear font cache if it gets too large
        if len(_font_cache) > 10:
            _font_cache.clear()
        
        # Clear image cache if it gets too large  
        if len(_image_cache) > 5:
            _image_cache.clear()
        
        # Force garbage collection
        gc.collect()

    def _format_location_short(self, location):
        """Format location coordinates into DMS (Degrees, Minutes, Seconds) format"""
        if not location or location.get('latitude') is None or location.get('longitude') is None:
            return "Unknown"
        
        lat = location['latitude']
        lon = location['longitude']
        
        def decimal_to_dms(decimal_degrees, is_latitude=True):
            """Convert decimal degrees to degrees, minutes, seconds format"""
            # Determine direction
            if is_latitude:
                direction = 'N' if decimal_degrees >= 0 else 'S'
            else:
                direction = 'E' if decimal_degrees >= 0 else 'W'
            
            # Work with absolute value
            abs_degrees = abs(decimal_degrees)
            
            # Extract degrees
            degrees = int(abs_degrees)
            
            # Extract minutes
            minutes_float = (abs_degrees - degrees) * 60
            minutes = int(minutes_float)
            
            # Extract seconds
            seconds = (minutes_float - minutes) * 60
            
            # Format with proper precision
            if ANDROID:
                # Shorter format for mobile - round seconds to nearest integer
                seconds = round(seconds)
                return f"{degrees}° {minutes}' {seconds}\" {direction}"
            else:
                # Desktop format with decimal seconds for more precision
                return f"{degrees}° {minutes}' {seconds:.1f}\" {direction}"
        
        # Format latitude and longitude
        lat_dms = decimal_to_dms(lat, is_latitude=True)
        lon_dms = decimal_to_dms(lon, is_latitude=False)
        
        return f"{lat_dms}, {lon_dms}"

    def _get_pump_icon_path(self):
        """Get the path to the pump icon."""
        app_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
        return os.path.join(app_dir, "icons", "pump.png")

    def _get_prediction_display(self, prediction):
        """Get display label (with level) and color for prediction."""
        print(f"DEBUG: Processing prediction: '{prediction}' (type: {type(prediction)})")
        
        # Get concentration label
        conc_label = self.CONC_LABEL_MAP.get(str(prediction), str(prediction))
        
        # Try case-insensitive match if not found
        if conc_label == str(prediction):
            for key, value in self.CONC_LABEL_MAP.items():
                if str(prediction).strip().lower() == key.strip().lower():
                    conc_label = value
                    break

        # Get level (append to label if found)
        level = self.LEVEL_MAP.get(conc_label)
        if level:
            display_label = f"{conc_label} ({level})"
        else:
            display_label = conc_label

        # Get color (default to black if not found)
        color_hex = self.CONC_COLOR_MAP.get(conc_label, "000000")

        # Try case-insensitive color match
        if color_hex == "000000" and conc_label != str(prediction):
            for color_key, color_val in self.CONC_COLOR_MAP.items():
                if color_key.lower() == conc_label.lower():
                    color_hex = color_val
                    break

        # Convert hex to RGB
        if color_hex and len(color_hex) == 6:
            try:
                rgb_color = tuple(int(color_hex[i:i+2], 16) for i in (0, 2, 4))
                print(f"DEBUG: Using color RGB: {rgb_color} for label: '{conc_label}'")
            except ValueError:
                rgb_color = (0, 0, 0)  # Black fallback
                print(f"DEBUG: Invalid hex color '{color_hex}', using black")
        else:
            rgb_color = (0, 0, 0)  # Black fallback
            print(f"DEBUG: No valid color found, using black")
        
        return display_label, rgb_color
        
    def save_to_history(self, prediction, date_str, composite_path):
        conc_label = self.CONC_LABEL_MAP.get(str(prediction), str(prediction))
        record = {
            "prediction": prediction,
            "concentration_label": conc_label,
            "date": date_str,
            "image_path": composite_path
        }
        self.history.insert(0, record)
        self.history = self.history[:100]
        try:
            with open(self.history_file, "w", encoding="utf-8") as f:
                json.dump(self.history, f, indent=2)
        except Exception as e:
            print(f"Failed to save history: {e}")

    def load_history(self):
        try:
            if os.path.exists(self.history_file):
                with open(self.history_file, "r", encoding="utf-8") as f:
                    self.history = json.load(f)
            else:
                self.history = []
        except Exception as e:
            print(f"Failed to load history: {e}")
            self.history = []

    def open_history_menu(self, instance):
        content = BoxLayout(orientation='vertical', padding=[dp(18), dp(12), dp(18), dp(12)], spacing=dp(12))
        back_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "back.png")
        view_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "view.png")
        back_btn = Button(
            background_normal=back_icon_path if os.path.exists(back_icon_path) else "",
            background_down=back_icon_path if os.path.exists(back_icon_path) else "",
            size_hint=(None, None),
            size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
            background_color=POPUP_BG,
            border=(0,0,0,0),
            padding=(0,0)
        )
        title_row = BoxLayout(orientation='horizontal', size_hint_y=None, height=dp(54), spacing=dp(10))
        title_row.add_widget(back_btn)
        title_row.add_widget(Label(text="[b]Analysis History[/b]", markup=True, font_size=sp(20), halign='center', valign='middle', color=POPUP_FG))
        # Add delete history button
        delete_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "delete.png")
        delete_btn = Button(
            background_normal=delete_icon_path if os.path.exists(delete_icon_path) else "",
            background_down=delete_icon_path if os.path.exists(delete_icon_path) else "",
            size_hint=(None, None),
            size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
            background_color=POPUP_BG,
            border=(0,0,0,0),
            color=POPUP_FG
        )
        def confirm_delete_history(instance):
            confirm_box = BoxLayout(orientation='vertical', padding=dp(18), spacing=dp(12))
            confirm_box.add_widget(Label(text="Are you sure you want to delete all history?", font_size=sp(17), color=POPUP_FG))
            btns = BoxLayout(orientation='horizontal', spacing=dp(18), size_hint_y=None, height=dp(48))
            yes_btn = Button(text="Yes", background_color=POPUP_BG, color=POPUP_FG, bold=True)
            no_btn = Button(text="No", background_color=POPUP_BG, color=POPUP_FG)
            btns.add_widget(yes_btn)
            btns.add_widget(no_btn)
            confirm_box.add_widget(btns)
            popup_confirm = SkyBluePopup(title="Confirm Delete", content=confirm_box, size_hint=(0.7, 0.3))
            def do_delete(*a):
                self.history = []
                try:
                    with open(self.history_file, "w", encoding="utf-8") as f:
                        json.dump(self.history, f, indent=2)
                except Exception as e:
                    print(f"Failed to clear history: {e}")
                popup_confirm.dismiss()
                # Close the history popup and reopen to refresh
                popup.dismiss()
                self.open_history_menu(None)
            yes_btn.bind(on_press=do_delete)
            no_btn.bind(on_press=popup_confirm.dismiss)
            popup_confirm.open()
        delete_btn.bind(on_press=confirm_delete_history)
        title_row.add_widget(delete_btn)
        content.add_widget(title_row)
        content.add_widget(Divider())
        if not self.history:
            content.add_widget(Label(text="No analyses yet.", size_hint_y=None, height=sp(40), color=POPUP_FG))
            popup = SkyBluePopup(title="", content=content, size_hint=(0.95, 0.95))
            back_btn.bind(on_press=popup.dismiss)
            popup.open()
            return
        scroll = ScrollView(size_hint=(1, 1))
        grid = GridLayout(cols=1, spacing=dp(10), size_hint_y=None, padding=(0,dp(2),0,dp(2)))
        grid.bind(minimum_height=grid.setter('height'))
        for idx, entry in enumerate(self.history):
            conc_label = entry.get("concentration_label", entry.get("prediction", ""))
            color = self.CONC_COLOR_MAP.get(conc_label, "000000")
            row = CardRow(orientation='horizontal', spacing=dp(15))
            
            # PPB label - centered in its space
            ppb_label = Label(
                text=f"[b][color={color}]{conc_label}[/color][/b]",
                markup=True, halign='center', valign='middle', size_hint_x=0.33, font_size=sp(17),
                color=POPUP_FG
            )
            ppb_label.bind(size=ppb_label.setter('text_size'))
            
            # Date/time - centered in its space
            date_label = Label(
                text=f"[size=14sp]{entry['date']}[/size]",
                markup=True, halign='center', valign='middle', size_hint_x=0.34, font_size=sp(14),
                color=POPUP_FG
            )
            date_label.bind(size=date_label.setter('text_size'))
            
            # View button container - centered in its space
            btn_container = BoxLayout(orientation='horizontal', size_hint_x=0.33)
            btn_container.add_widget(Widget())  # Left spacer
            
            view_btn = Button(
                background_normal=view_icon_path if os.path.exists(view_icon_path) else "",
                background_down=view_icon_path if os.path.exists(view_icon_path) else "",
                size_hint=(None, None),
                size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
                background_color=POPUP_BG,
                border=(0, 0, 0, 0),
                padding=(0, 0),
                color=POPUP_FG
            )
            view_btn.bind(on_press=lambda btn, path=entry["image_path"]: self.view_history_image_with_share(path))
            
            btn_container.add_widget(view_btn)
            btn_container.add_widget(Widget())  # Right spacer
            
            row.add_widget(ppb_label)
            row.add_widget(date_label)
            row.add_widget(btn_container)
            grid.add_widget(row)
        scroll.add_widget(grid)
        content.add_widget(scroll)
        popup = SkyBluePopup(title="", content=content, size_hint=(0.95, 0.95))
        back_btn.bind(on_press=popup.dismiss)
        popup.open()

    def view_history_image_with_share(self, path):
        header_height = ICON_SIZE_SMALL  # Use consistent icon size

        box = BoxLayout(orientation='vertical', padding=[dp(15)] * 4, spacing=dp(15))
        header = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=header_height,
            spacing=dp(10)
        )

        back_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "back.png")
        back_btn = Button(
            background_normal=back_icon_path if os.path.exists(back_icon_path) else "",
            background_down=back_icon_path if os.path.exists(back_icon_path) else "",
            size_hint=(None, None),
            size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
            background_color=POPUP_BG,
            border=(0,0,0,0),
            padding=(0,0),
            color=POPUP_FG
        )
        share_btn = Button(
            background_normal=self.share_icon_path if os.path.exists(self.share_icon_path) else "",
            background_down=self.share_icon_path if os.path.exists(self.share_icon_path) else "",
            size_hint=(None, None),
            size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
            background_color=POPUP_BG,
            border=(0, 0, 0, 0),
            padding=(0, 0),
            color=POPUP_FG
        )

        label = Label(
            text="[b]History Image[/b]",
            size_hint=(1, None),
            height=header_height,
            font_size=sp(19),
            color=POPUP_FG,
            halign='center',
            valign='middle',
            markup=True,
            text_size=(0, None)  # Ensures horizontal centering
        )
        label.bind(size=lambda inst, val: setattr(inst, 'text_size', (inst.width, None)))

        header.add_widget(back_btn)
        header.add_widget(label)
        header.add_widget(share_btn)
        img = KivyImage(source=path, allow_stretch=True, keep_ratio=True)
        box.add_widget(header)
        box.add_widget(img)
        popup = SkyBluePopup(title="", content=box, size_hint=(0.95, 0.95))
        back_btn.bind(on_press=popup.dismiss)
        share_btn.bind(on_press=lambda btn: self.save_and_view_in_gallery(path))
        popup.open()

    def share_latest_analysis(self, instance):
        if self.composite_image_path and os.path.exists(self.composite_image_path):
            self.show_share_popup(self.composite_image_path)
        else:
            #self.status_label.text = "[color=ff0000]No analysis to share yet.[/color]"
            pass

    def show_share_popup(self, image_path):
        box = BoxLayout(orientation='vertical', padding=[dp(15)]*4, spacing=dp(15))
        header = BoxLayout(orientation='horizontal', size_hint_y=None, height=ICON_SIZE_SMALL, spacing=dp(10))

        # Icon paths
        back_icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons", "back.png")
        share_icon_path = self.share_icon_path

        # Buttons
        back_btn = Button(
            background_normal=back_icon_path if os.path.exists(back_icon_path) else "",
            background_down=back_icon_path if os.path.exists(back_icon_path) else "",
            size_hint=(None, None),
            size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
            background_color=POPUP_BG,
            border=(0,0,0,0),
            padding=(0,0),
            color=POPUP_FG
        )
        share_btn = Button(
            background_normal=share_icon_path if os.path.exists(share_icon_path) else "",
            background_down=share_icon_path if os.path.exists(share_icon_path) else "",
            size_hint=(None, None),
            size=(ICON_SIZE_SMALL, ICON_SIZE_SMALL),
            background_color=POPUP_BG,
            border=(0, 0, 0, 0),
            padding=(0, 0),
            color=POPUP_FG
        )

        # Label
        label = Label(
            text="[b]Share Analysis[/b]",
            size_hint=(1, 1),
            font_size=sp(19),
            color=POPUP_FG,
            halign='center',
            valign='middle',
            markup=True,
            text_size=(0, None),
        )
        label.bind(size=lambda inst, val: setattr(inst, 'text_size', (inst.width, None)))

        # Add widgets to header: back, label, share
        header.add_widget(back_btn)
        header.add_widget(label)
        header.add_widget(share_btn)

        # Image and layout
        img = KivyImage(source=image_path, allow_stretch=True, keep_ratio=True)
        box.add_widget(header)
        box.add_widget(img)

        # Popup
        popup = SkyBluePopup(title="", content=box, size_hint=(0.95, 0.95))
        back_btn.bind(on_press=popup.dismiss)
        share_btn.bind(on_press=lambda btn: self.save_and_view_in_gallery(image_path))
        popup.open()

    def save_and_view_in_gallery(self, image_path, popup=None):
        try:
            saved_uri = self.save_to_gallery_and_get_uri(image_path, popup)
            if saved_uri:
                if ANDROID:
                    from jnius import autoclass
                    Intent = autoclass('android.content.Intent')
                    Uri = autoclass('android.net.Uri')
                    PythonActivity = autoclass('org.kivy.android.PythonActivity')
                    intent = Intent()
                    intent.setAction(Intent.ACTION_VIEW)
                    intent.setDataAndType(saved_uri, "image/jpeg")
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    activity = PythonActivity.mActivity
                    activity.startActivity(intent)
                    #self.status_label.text = '[color=00ff00]Opened in Gallery[/color]'
                else:
                    import subprocess
                    import platform
                    if platform.system() == 'Windows':
                        os.startfile(image_path)
                    elif platform.system() == 'Darwin':
                        subprocess.call(['open', image_path])
                    else:
                        subprocess.call(['xdg-open', image_path])
                    #self.status_label.text = '[color=00ff00]Image opened[/color]'
            else:
                #self.status_label.text = '[color=ff0000]Could not open in gallery[/color]'
                pass
        except Exception as e:
            print(f"Error opening in gallery: {e}")
            import traceback
            traceback.print_exc()
            #self.status_label.text = '[color=ff0000]Error opening in gallery[/color]'

    def save_to_gallery_and_get_uri(self, image_path, popup=None):
        try:
            if ANDROID:
                from jnius import autoclass
                PythonActivity = autoclass('org.kivy.android.PythonActivity')
                ContentValues = autoclass('android.content.ContentValues')
                FileInputStream = autoclass('java.io.FileInputStream')
                File = autoclass('java.io.File')
                Build = autoclass('android.os.Build$VERSION')
                MediaStoreImages = autoclass('android.provider.MediaStore$Images$Media')
                EXTERNAL_CONTENT_URI = MediaStoreImages.EXTERNAL_CONTENT_URI
                context = PythonActivity.mActivity.getApplicationContext()
                values = ContentValues()
                filename = os.path.basename(image_path)
                DISPLAY_NAME = autoclass('android.provider.MediaStore$MediaColumns').DISPLAY_NAME
                MIME_TYPE = autoclass('android.provider.MediaStore$MediaColumns').MIME_TYPE
                RELATIVE_PATH = autoclass('android.provider.MediaStore$MediaColumns').RELATIVE_PATH
                values.put(DISPLAY_NAME, filename)
                values.put(MIME_TYPE, "image/jpeg")
                if Build.SDK_INT >= 29:
                    values.put(RELATIVE_PATH, "Pictures/Arsenic")
                resolver = context.getContentResolver()
                imageUri = resolver.insert(EXTERNAL_CONTENT_URI, values)
                if imageUri:
                    outputStream = resolver.openOutputStream(imageUri)
                    inputStream = FileInputStream(File(image_path))
                    buffer = bytearray(1024)
                    while True:
                        length = inputStream.read(buffer)
                        if length <= 0:
                            break
                        outputStream.write(buffer, 0, length)
                    outputStream.close()
                    inputStream.close()
                    #self.status_label.text = '[color=00ff00]Saved to gallery[/color]'
                    return imageUri
                else:
                    #self.status_label.text = '[color=ff0000]Could not save to gallery[/color]'
                    return None
            else:
                import shutil
                pictures_dir = os.path.expanduser('~/Pictures')
                if not os.path.exists(pictures_dir):
                    pictures_dir = os.path.expanduser('~')
                arsenic_dir = os.path.join(pictures_dir, 'Arsenic')
                os.makedirs(arsenic_dir, exist_ok=True)
                dest_path = os.path.join(arsenic_dir, os.path.basename(image_path))
                shutil.copy2(image_path, dest_path)
                #self.status_label.text = f'[color=00ff00]Saved to {dest_path}[/color]'
                if popup:
                    popup.dismiss()
                return dest_path
        except Exception as e:
            print(f"Error saving to gallery: {e}")
            import traceback
            traceback.print_exc()
            #self.status_label.text = '[color=ff0000]Error saving to gallery[/color]'
            return None

    def get_now_str(self):
        import time
        return time.strftime("%Y-%m-%d %H:%M:%S")

if __name__ == '__main__':
    ImageProcessorApp().run()