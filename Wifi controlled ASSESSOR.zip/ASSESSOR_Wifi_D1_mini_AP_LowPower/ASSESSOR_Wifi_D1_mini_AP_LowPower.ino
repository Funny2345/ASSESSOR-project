/*
  ASSESSOR temperature controller — ESP8266 D1 mini
  Access point: ASSESSOR / 12345678 / http://192.168.4.1
  AHT10: SDA=D2, SCL=D1; HEATER PWM=D5.
  Power: modest AP RF power, scheduled sensing/PID. No deep sleep in AP mode.
  IMPORTANT: D5 must drive a suitable MOSFET/driver, NOT a heater directly.
*/
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <Wire.h>
#include <Adafruit_AHTX0.h>
#include <math.h>

const char* AP_SSID = "ASSESSOR";
const char* AP_PASSWORD = "12345678";
const IPAddress AP_IP(192,168,4,1);
const IPAddress AP_GATEWAY(192,168,4,1);
const IPAddress AP_SUBNET(255,255,255,0);
const uint8_t AP_CHANNEL = 6;
const float AP_TX_POWER_DBM = 10.5f;  // 0..20.5 dBm for ESP8266

#define HEATER_PIN D5
const unsigned long SENSOR_INTERVAL_MS = 2000;
const unsigned long CONTROL_INTERVAL_MS = 250;
const unsigned long SENSOR_TIMEOUT_MS = 7000;

ESP8266WebServer server(80);
Adafruit_AHTX0 aht;
bool sensorReady = false;
bool sensorValid = false;
float temperature = NAN;
float humidity = NAN;
float targetTemp = 30.0f;
bool pidEnable = true;
const float Kp = 175.0f;
const float Ki = 0.75f;
const float Kd = 25.0f;
float integral = 0.0f;
float lastError = 0.0f;
unsigned long lastPID = 0;
unsigned long lastSensor = 0;
unsigned long lastControl = 0;
unsigned long lastGoodSensor = 0;
int pwmOutput = 0;

void applyHeater(int requested) {
  pwmOutput = constrain(requested, 0, 1023);
  analogWrite(HEATER_PIN, pwmOutput);
}

void startAccessPoint() {
  WiFi.persistent(false);  // avoid flash writes
  WiFi.mode(WIFI_AP);
  WiFi.softAPdisconnect(true);
  WiFi.softAPConfig(AP_IP, AP_GATEWAY, AP_SUBNET);
  WiFi.setOutputPower(AP_TX_POWER_DBM);
  const bool ok = WiFi.softAP(AP_SSID, AP_PASSWORD, AP_CHANNEL, false, 2);
  WiFi.setOutputPower(AP_TX_POWER_DBM);
  Serial.println(ok ? F("AP started") : F("AP startup FAILED"));
  Serial.print(F("SSID: ")); Serial.println(AP_SSID);
  Serial.print(F("IP: ")); Serial.println(WiFi.softAPIP());
}

void readSensor() {
  if (!sensorReady) {
    sensorValid = false;
    applyHeater(0);
    return;
  }
  sensors_event_t h, t;
  if (aht.getEvent(&h, &t) && isfinite(t.temperature) && isfinite(h.relative_humidity)
      && t.temperature > -40.0f && t.temperature < 125.0f
      && h.relative_humidity >= 0.0f && h.relative_humidity <= 100.0f) {
    temperature = t.temperature;
    humidity = h.relative_humidity;
    sensorValid = true;
    lastGoodSensor = millis();
  } else {
    sensorValid = false;
    applyHeater(0);
    Serial.println(F("AHT10 read error: heater OFF"));
  }
}

void controlTemperature() {
  const unsigned long now = millis();
  if (!pidEnable || !sensorValid || (now - lastGoodSensor > SENSOR_TIMEOUT_MS)) {
    applyHeater(0);
    integral = 0;
    lastPID = 0;
    return;
  }
  const float error = targetTemp - temperature;
  float dt = (lastPID == 0) ? CONTROL_INTERVAL_MS / 1000.0f : (now - lastPID) / 1000.0f;
  lastPID = now;
  dt = constrain(dt, 0.01f, 2.0f);
  if (error > 0.5f) {
    integral = 0;
    lastError = error;
    applyHeater(1023);
    return;
  }
  integral = constrain(integral + error * dt, -300.0f, 300.0f);
  const float derivative = (error - lastError) / dt;
  lastError = error;
  float output = Kp * error + Ki * integral + Kd * derivative;
  if (temperature > targetTemp + 0.3f) output = 0;
  applyHeater((int)constrain(output, 0.0f, 1023.0f));
}

void sendData() {
  String json;
  json.reserve(180);
  json = F("{\"temp\":");
  json += sensorValid ? String(temperature,2) : F("null");
  json += F(",\"hum\":");
  json += sensorValid ? String(humidity,1) : F("null");
  json += F(",\"target\":"); json += String(targetTemp,1);
  json += F(",\"pwm\":"); json += String(pwmOutput);
  json += F(",\"pid\":"); json += pidEnable ? F("true") : F("false");
  json += F(",\"sensorOK\":"); json += sensorValid ? F("true") : F("false");
  json += F(",\"ip\":\""); json += WiFi.softAPIP().toString();
  json += F("\"}");
  server.send(200, F("application/json"), json);
}

void setControl() {
  if (server.hasArg("temp")) {
    const String arg = server.arg("temp");
    const float proposed = arg.toFloat();
    // Limit user-set values to moderate incubator temperatures.
    if (proposed < 15.0f || proposed > 45.0f) {
      server.send(400, F("text/plain"), F("Target temperature must be 15-45 C"));
      return;
    }
    targetTemp = proposed;
    integral = 0;
    lastPID = 0;
  }
  if (server.hasArg("pid")) {
    pidEnable = server.arg("pid") == "1";
    integral = 0;
    lastPID = 0;
    if (!pidEnable) applyHeater(0);
  }
  server.send(200, F("text/plain"), F("OK"));
}

static const char INDEX_HTML[] PROGMEM = R"=====(


<!DOCTYPE html>

<html>

<head>

<meta name="viewport" content="width=device-width,initial-scale=1">

<title>ASSESSOR Controller</title>

<style>

body{

font-family:Arial;

text-align:center;

background:#eeeeee;

}


.box{

background:white;

margin:15px;

padding:20px;

border-radius:15px;

}


.big{

font-size:45px;

color:#0066cc;

}


button{

padding:12px;

margin:5px;

border:0;

border-radius:8px;

background:#0066cc;

color:white;

}


input{

font-size:20px;

width:90px;

}


</style>

</head>


<body>


<div class="box">

<h2>
ASSESSOR Controller
</h2>

</div>


<div class="box">

<div>
Temperature
</div>


<div class="big">

<span id="temp">
--

</span>

C

</div>


<p>

Humidity:

<span id="hum">
--

</span>

%

</p>

</div>




<div class="box">


Target:

<input id="target"
value="30">


<button onclick="setTemp()">

SET

</button>


</div>




<div class="box">


PWM:

<span id="pwm">
--

</span>

%


<br><br>


<button onclick="pid(1)">
PID ON
</button>


<button onclick="pid(0)">
PID OFF
</button>


</div>




<div class="box">

IP:

<span id="ip">
--

</span>

</div>




<script>


let editing=false;


target.onfocus=function(){

editing=true;

}



target.onblur=function(){

editing=false;

}




function update(){


if(editing)
return;


fetch("/data")

.then(r=>r.json())

.then(d=>{


document.getElementById("temp")
.innerHTML=(d.temp===null ? "--" : d.temp.toFixed(2));



document.getElementById("hum")
.innerHTML=(d.hum===null ? "--" : d.hum.toFixed(1));



document.getElementById("pwm")
.innerHTML=
Math.round(d.pwm/10.23);



document.getElementById("ip")
.innerHTML=d.ip;



document.getElementById("target")
.value=d.target;



});


}



function setTemp(){


let v =
document.getElementById("target").value;



fetch("/set?temp="+encodeURIComponent(v)).then(update);


}




function pid(x){

fetch("/set?pid="+x).then(update);

}



setInterval(update,5000);


update();


</script>


</body>

</html>



)=====";

void rootPage() {
  server.send_P(200, PSTR("text/html; charset=utf-8"), INDEX_HTML);
}

void setup() {
  Serial.begin(74880);
  delay(100);
  pinMode(HEATER_PIN, OUTPUT);
  digitalWrite(HEATER_PIN, LOW);
  analogWriteRange(1023);
  analogWriteFreq(1000);
  applyHeater(0);
  Wire.begin(D2, D1);
  sensorReady = aht.begin();
  Serial.println(sensorReady ? F("AHT10 OK") : F("AHT10 ERROR: heater disabled"));
  startAccessPoint();
  server.on("/", HTTP_GET, rootPage);
  server.on("/data", HTTP_GET, sendData);
  server.on("/set", HTTP_GET, setControl);
  server.begin();
  Serial.println(F("Open http://192.168.4.1"));
  lastSensor = millis() - SENSOR_INTERVAL_MS;
  lastControl = millis();
}

void loop() {
  server.handleClient();
  const unsigned long now = millis();
  if (now - lastSensor >= SENSOR_INTERVAL_MS) {
    lastSensor = now;
    readSensor();
  }
  if (now - lastControl >= CONTROL_INTERVAL_MS) {
    lastControl = now;
    controlTemperature();
  }
  delay(10);  // cooperative yield; Wi-Fi AP stays responsive
}
