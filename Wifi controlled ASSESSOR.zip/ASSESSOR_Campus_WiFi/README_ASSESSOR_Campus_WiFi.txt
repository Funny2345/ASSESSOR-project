# ASSESSOR – Campus Wi-Fi User Guide

This guide applies to the **original ASSESSOR_Wifi_D1_mini.ino** firmware, which connects to the **ZJUWLAN** campus Wi-Fi network. It does **not** apply to the standalone Wi-Fi hotspot (AP) version.

## Connection information

- **Wi-Fi network (SSID):** `ZJUWLAN`
- **Control interface:** `http://<device-ip-address>`
- **Connection mode:** Campus Wi-Fi (station/client mode)
- **Default control address:** **Not fixed**. The device receives an IP address from the network.

## How to connect

1. Power on the ASSESSOR device within range of `ZJUWLAN`.
2. Connect your phone or computer to the same campus network.
3. Find the device's current IP address (see below).
4. Enter `http://<device-ip-address>` in a web browser to open the temperature-control interface.

## How to find the device IP address

1. Connect the D1 mini to a computer by USB.
2. Open **Arduino IDE → Tools → Serial Monitor**.
3. Set the serial baud rate to **74880**.
4. Restart the device if necessary and look for the message `IP: xxx.xxx.xxx.xxx` after `WiFi connected`.
5. Enter that address in your browser, for example `http://192.168.1.123` (**example only; do not assume this is your device's address**).

## Important campus-network limitations

**1. IP addresses may change.** Campus networks commonly assign IP addresses dynamically (DHCP). The device's IP may change after reconnection, a network lease change, or on a later day. **Check the current IP each time you cannot access the device.**

**2. Local device-to-device connections may be blocked.** Some campus networks use client isolation, VLAN separation, or firewall rules that prevent a phone or computer from reaching the ASSESSOR, even when both devices are connected to `ZJUWLAN`. **An IP address alone cannot bypass these restrictions.**

**3. Network login requirements may prevent connection.** The original firmware connects to `ZJUWLAN` without specifying a Wi-Fi password and does not handle a captive-portal sign-in or 802.1X authentication. The network must permit this connection method for the device to connect successfully.

## Troubleshooting

| Problem | What to check |
|---|---|
| No `WiFi connected` message | Confirm that `ZJUWLAN` is available and that the network accepts this type of device. |
| IP address changed | Recheck the current address in Serial Monitor. |
| Wi-Fi connected, but web page won't open | Verify the address and that the phone/computer can reach the device. Campus client isolation or firewall rules may block access. |
| Phone switches to mobile data | Keep the phone on the intended Wi-Fi network when accessing the local device. |

## Recommended alternative

For reliable operation without campus-network restrictions, use the **ASSESSOR Wi-Fi hotspot (AP) firmware** instead:

- **Wi-Fi ID:** `ASSESSOR`
- **Password:** `12345678`
- **Control address:** `http://192.168.4.1`

The hotspot version works independently of campus Wi-Fi and uses a fixed local control address. It requires uploading the AP firmware; the original campus Wi-Fi firmware does not create this hotspot.
