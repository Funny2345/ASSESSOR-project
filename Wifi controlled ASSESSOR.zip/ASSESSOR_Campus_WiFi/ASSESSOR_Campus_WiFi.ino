#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <Wire.h>
#include <Adafruit_AHTX0.h>


// ========================
// WiFi
// ========================

const char* ssid = "ZJUWLAN";

ESP8266WebServer server(80);


// ========================
// Sensor
// ========================

Adafruit_AHTX0 aht;


// ========================
// Hardware
// ========================

#define HEATER_PIN D5



// ========================
// Temperature data
// ========================

float temperature = 0;
float humidity = 0;

float targetTemp = 30.0;



// ========================
// PID
// 5x stronger
// ========================

bool pidEnable = true;


float Kp = 175;
float Ki = 0.75;
float Kd = 25;


float integral = 0;
float lastError = 0;


unsigned long lastPID = 0;



int pwmOutput = 0;



unsigned long lastSensor = 0;



// ========================
// WiFi
// ========================

void connectWiFi()
{

  WiFi.mode(WIFI_STA);

  WiFi.begin(ssid);


  Serial.println();
  Serial.print("Connecting WiFi");


  int count = 0;


  while(WiFi.status()!=WL_CONNECTED)
  {

    delay(500);

    Serial.print(".");


    count++;


    if(count>40)
    {

      Serial.println();

      Serial.println("WiFi failed");

      return;

    }

  }


  Serial.println();

  Serial.println("WiFi connected");


  Serial.print("IP: ");

  Serial.println(WiFi.localIP());

}



// ========================
// Read AHT10
// ========================

void readSensor()
{

  sensors_event_t h;
  sensors_event_t t;


  aht.getEvent(&h,&t);


  temperature = t.temperature;

  humidity = h.relative_humidity;


}



// ========================
// Temperature control
// ========================

void controlTemperature()
{


  float error = targetTemp - temperature;



  /*
    Fast heating mode

    Until reaching target:
    Full power
  */

  if(error > 0.5)
  {

    pwmOutput = 1023;

    integral = 0;

    return;

  }



  /*
    PID near target
  */


  unsigned long now = millis();


  float dt =
  (now-lastPID)/1000.0;



  if(dt<=0)
    return;


  lastPID = now;



  integral += error*dt;



  if(integral>300)
    integral=300;


  if(integral<-300)
    integral=-300;




  float derivative =
  (error-lastError)/dt;



  float output =
      Kp*error
    + Ki*integral
    + Kd*derivative;



  lastError = error;



  pwmOutput = (int)output;



  if(pwmOutput>1023)
    pwmOutput=1023;


  if(pwmOutput<0)
    pwmOutput=0;




  // safety

  if(temperature > targetTemp+0.3)
  {

    pwmOutput=0;

  }



}




// ========================
// API
// ========================


void sendData()
{


String json="{";


json += "\"temp\":";
json += String(temperature,2);


json += ",\"hum\":";
json += String(humidity,1);



json += ",\"target\":";
json += String(targetTemp,1);



json += ",\"pwm\":";
json += String(pwmOutput);



json += ",\"ip\":\"";
json += WiFi.localIP().toString();

json += "\"}";



server.send(
200,
"application/json",
json
);


}




void setControl()
{


if(server.hasArg("temp"))
{

targetTemp =
server.arg("temp").toFloat();


Serial.print(
"Target temperature changed: "
);


Serial.print(targetTemp);


Serial.println(" C");


}



if(server.hasArg("pid"))
{


pidEnable =
server.arg("pid")=="1";


Serial.print("PID: ");


Serial.println(
pidEnable ? "ON":"OFF"
);


}



server.send(
200,
"text/plain",
"OK"
);


}




// ========================
// Basic test page
// ========================

void rootPage()
{


String page = R"=====(

<!DOCTYPE html>

<html>

<head>

<meta name="viewport" content="width=device-width,initial-scale=1">

<title>
Temperature Controller
</title>

<style>

body{

font-family:Arial;

text-align:center;

background:#eeeeee;

}


.box{

background:white;

margin:15px;

padding:20px;

border-radius:15px;

}


.big{

font-size:45px;

color:#0066cc;

}


button{

padding:12px;

margin:5px;

border:0;

border-radius:8px;

background:#0066cc;

color:white;

}


input{

font-size:20px;

width:90px;

}


</style>

</head>


<body>


<div class="box">

<h2>
Temperature Controller
</h2>

</div>


<div class="box">

<div>
Temperature
</div>


<div class="big">

<span id="temp">
--

</span>

C

</div>


<p>

Humidity:

<span id="hum">
--

</span>

%

</p>

</div>




<div class="box">


Target:

<input id="target"
value="30">


<button onclick="setTemp()">

SET

</button>


</div>




<div class="box">


PWM:

<span id="pwm">
--

</span>

%


<br><br>


<button onclick="pid(1)">
PID ON
</button>


<button onclick="pid(0)">
PID OFF
</button>


</div>




<div class="box">

IP:

<span id="ip">
--

</span>

</div>




<script>


let editing=false;


target.onfocus=function(){

editing=true;

}



target.onblur=function(){

editing=false;

}




function update(){


if(editing)
return;


fetch("/data")

.then(r=>r.json())

.then(d=>{


document.getElementById("temp")
.innerHTML=d.temp.toFixed(2);



document.getElementById("hum")
.innerHTML=d.hum.toFixed(1);



document.getElementById("pwm")
.innerHTML=
Math.round(d.pwm/10.23);



document.getElementById("ip")
.innerHTML=d.ip;



document.getElementById("target")
.value=d.target;



});


}



function setTemp(){


let v =
document.getElementById("target").value;



fetch(
"/set?temp="+v
);


}




function pid(x){

fetch(
"/set?pid="+x
);

}



setInterval(update,5000);


update();


</script>


</body>

</html>


)=====";


server.send(
200,
"text/html",
page
);


}




// ========================
// Setup
// ========================


void setup()
{


Serial.begin(74880);


delay(500);


Serial.println();

Serial.println(
"Temperature Controller Start"
);



Wire.begin(D2,D1);



if(aht.begin())

Serial.println("AHT10 OK");

else

Serial.println("AHT10 ERROR");




pinMode(
HEATER_PIN,
OUTPUT
);



analogWriteRange(1023);

analogWriteFreq(1000);



connectWiFi();



server.on(
"/",
rootPage
);



server.on(
"/data",
sendData
);



server.on(
"/set",
setControl
);



server.begin();



Serial.println(
"HTTP Server Ready"
);


}




// ========================
// Loop
// ========================

void loop()
{


server.handleClient();



if(WiFi.status()!=WL_CONNECTED)
{

connectWiFi();

}



if(
millis()-lastSensor>2000
)

{

lastSensor=millis();

readSensor();

}



if(pidEnable)
{

controlTemperature();


analogWrite(
HEATER_PIN,
pwmOutput
);

}


else

{

analogWrite(
HEATER_PIN,
0
);

}



delay(5);


}